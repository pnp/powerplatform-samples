from opencensus.ext.azure.log_exporter import AzureLogHandler
import logging
import json
from promptflow import tool
from datetime import datetime

# Configure Application Insights Logger
logger = logging.getLogger("PromptFlowLogger")
logger.addHandler(AzureLogHandler(connection_string="InstrumentationKey=10548e08-3a31-4e9f-aba8-f5fb394fcc25;IngestionEndpoint=https://francecentral-1.in.applicationinsights.azure.com/;LiveEndpoint=https://francecentral.livediagnostics.monitor.azure.com/;ApplicationId=21c07d14-e3da-44ad-984a-a9e7313d522b"))
logger.setLevel(logging.INFO)

# Static query ID for telemetry filtering
STATIC_QUERY_ID = "termbuddy-telemetry-log"

@tool
def main(
    question: str,
    user_prompt: str,
    temperature: float,
    response: str,
    term: str,
    action: str
):
    # Generate session ID based on the current timestamp
    session_id = datetime.utcnow().strftime("%y%m%d-%H%M%S")

    # Aggregate telemetry data
    telemetry_data = {
        "static_query_id": STATIC_QUERY_ID,
        "session_id": session_id,
        "question": question,
        "user_prompt": user_prompt,
        "temperature": temperature,
        "response": response,
        "term": term,
        "action": action
    }

    # Log telemetry data directly without converting the dictionary
    logger.info("Aggregated Flow Outputs", extra={"custom_dimensions": telemetry_data})

    # Return telemetry data if needed
    return telemetry_data